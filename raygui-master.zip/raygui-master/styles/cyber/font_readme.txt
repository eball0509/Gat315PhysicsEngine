Thank you for downloading the free Grixel fonts. You can use them in your personal and commercial projects too. They include Western European, Central European, Turkish and Greek characters. They are Unicode TrueType fonts and are optimized to work in both Windows XP and Mac OS X platforms using Adobe Photoshop CS2 and Macromedia Flash 8.


Grixel fonts are under Creative Commons Attribution-NoDerivs 2.5 License which can be found here:

http://creativecommons.org/licenses/by-nd/2.5/

===============================================================
Attribution-NoDerivs 2.5

You are free:

    * to copy, distribute, display, and perform the work
    * to make commercial use of the work

Under the following conditions:

by 	
Attribution. You must attribute the work in the manner specified by the author or licensor.

nd 	
No Derivative Works. You may not alter, transform, or build upon this work.

    * For any reuse or distribution, you must make clear to others the license terms of this work.
    * Any of these conditions can be waived if you get permission from the copyright holder.

Your fair use and other rights are in no way affected by the above.
===============================================================


In no event shall Nikos Giannakopoulos be held liable to you for any consequential or incidental damages, including any lost revenue, profits, goodwill or savings, or for any claim by any third party caused by using these fonts.

Please read the UsageGuides.pdf before you use them.


Grixel - Greek pixel fonts | Nikos Giannakopoulos | www.grixel.gr